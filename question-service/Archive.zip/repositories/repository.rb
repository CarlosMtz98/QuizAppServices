module Repository
  def instance(logger)
    raise "Not implemented"
  end

  def find
    raise "Not implemented jet"
  end

  def find_by(id)
    raise "Not implemented jet"
  end

  def create(entity)
    raise "Not implemented jet"
  end

  def update(id, entity)
    raise "Not implemented jet"
  end

  def delete(id)
    raise "Not implemented jet"
  end

  def is_valid_entity?(entity)
    raise "Not implemented jet"
  end
end